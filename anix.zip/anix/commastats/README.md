# Comma statistics

## Installation

Copy the extension to phpBB/ext/anix/commastats

Go to "ACP" > "Customise" > "Extensions" and enable the "Comma statistics" extension.

## License

[GNU General Public License v2](license.txt)
